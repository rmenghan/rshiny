library(shiny)
library(shiny)
library(ggplot2)
library(ggthemes)
library(plotly)
str(mpg)
ui <- basicPage(
    plotlyOutput("plot1"),
    verbatimTextOutput("info")
)

server <- function(input, output) {
    
    output$plot1 <- renderPlotly({
        print(
            ggplotly(gp<-ggplot(mpg, aes(x=displ, y = hwy, color=drv)) + 
                         geom_point()+
                         geom_smooth()
            ))
    })
    
    output$info <- renderText({
        paste0("x=", input$plot_click$x, "\ny=", input$plot_click$y)
    })
}


# Run the application 
shinyApp(ui = ui, server = server)

